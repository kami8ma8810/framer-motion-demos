export default function PageFour() {
  return (
    <div className="page page-four">
      <h1>Four</h1>
    </div>
  );
}
