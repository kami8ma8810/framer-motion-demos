export default function Index() {
  return (
    <div className="page page-index">
      <h1>Index</h1>
    </div>
  );
}
