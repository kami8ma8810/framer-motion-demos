export default function PageTwo() {
  return (
    <div className="page page-two">
      <h1>Two</h1>
    </div>
  );
}
