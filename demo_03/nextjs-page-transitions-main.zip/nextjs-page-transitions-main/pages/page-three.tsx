export default function PageThree() {
  return (
    <div className="page page-three">
      <h1>Three</h1>
    </div>
  );
}
