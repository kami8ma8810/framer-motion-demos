export default function PageOne() {
  return (
    <div className="page page-four">
      <h1>One</h1>
    </div>
  );
}
