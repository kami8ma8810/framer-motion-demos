# Demo of full page transitions with Next.js and Framer Motion library.

Read the article: https://dev.to/ivandotv/full-page-transitions-with-next-js-1co5

Check out the demo: https://nextjs-full-page-transitions.netlify.app/

Some of the transitions:

![slide-right](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/a5xo7z1jfreiaf2n9ve8.gif)
![fade-back](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/qfni3wxnmi3x4ntphron.gif)
![rotate-z](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/plwfrghfs0k98im0w1b8.gif)
