export { default } from 'containers/IndexPage/IndexPage';
export { getStaticProps } from 'containers/IndexPage/data';
