export const ISR_TIMEOUT = process.env.ENV === 'local' ? 3 : 50;
