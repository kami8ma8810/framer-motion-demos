export const pageTransitionDuration = 1200;

export const indexCurtainDuration = pageTransitionDuration * 0.68;
