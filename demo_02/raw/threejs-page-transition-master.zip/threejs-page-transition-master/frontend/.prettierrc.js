module.exports = {
  semi: true,
  singleQuote: true,
  trailingComma: "all",
  printWidth: 80,
};
